Control ship with arrow keys.
Shoot with spacebar.